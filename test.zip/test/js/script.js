$(document).ready(function() {

	$(".modalbox").fancybox();

	$('.modal__button').on('click',function(){
		$.fancybox.close();
		$(".modalbox").fancybox();
	});
	
	$('.nav__burger').on('click', function(){
		$(this).closest('.nav').toggleClass('nav-open');  
	});

	$(document).on('scroll', function(){
		let parallaxOffset = window.pageYOffset - 50;
		$('.header__parallax').css('top', -parallaxOffset);

		parallaxOffset = window.pageYOffset + 20;
		$('.parallax').css('top', +parallaxOffset);
	});
});
